# Diagnostic Complet : Signalisation Qualité Live & Incidents RC29.4

## 🎯 Objectif
Diagnostiquer l'état de complétion des deux interfaces critiques :
1. **Signalisation Qualité Live** (Administration) - Configuration des règles d'alerte
2. **Incidents / Alertes Live** - Historique et statistiques des incidents

**État rapporté:** "Mon travail n'est pas terminé correctement"

---

## INTERFACE 1: SIGNALISATION QUALITÉ LIVE

### ✅ Implémentation Existante (live-quality-admin.js - 24 KB)

#### Fonctionnalités Implémentées:
1. **Gestion des niveaux de couleur**
   - Création/édition/suppression de niveaux avec couleurs personnalisées
   - Support des niveaux de repli (fallback)
   - Classement par rang
   - Génération dynamique de CSS pour les couleurs

2. **Gestion des règles de signalisation**
   - 6 types de cibles : GLOBAL, SERVICE, GROUP, CAMPAIGN, QUEUE, AGENT
   - Conditions multi-critères avec opérateurs (>=, <=, >, <, ==, !=)
   - Mode simple (presets) et mode avancé (règles personnalisées)
   - Anti-bruit : durée minimale, retour normal, cooldown, échantillon minimum
   - Persistance dans sessionStorage du mode (simple/avancé)

3. **Interface utilisateur**
   - Mode simple avec cartes de presets
   - Mode avancé avec gestion complète des niveaux et règles
   - Panneau de sélection des cibles avec recherche
   - Détails des conditions avec conversion automatique d'unités
   - Validation des champs et messages d'erreur

#### Endpoints API Attendus:
```
✓ GET /api/live/quality/config
  Retourne: { metrics[], operators[], scope_types[], levels[], rules[], presets[] }

✓ POST /api/live/quality/level
  Body: { original_level_key, level_key, label, rank, color, enabled, is_fallback }

✓ POST /api/live/quality/level-delete
  Body: { level_key }

✓ POST /api/live/quality/rule
  Body: { id?, name, enabled, scope_type, target_keys[], level_key, match_mode, min_duration_seconds, recovery_seconds, cooldown_seconds, min_sample_size, allow_partial, conditions[] }

✓ POST /api/live/quality/rule-delete
  Body: { id }

✓ GET /api/live/supervision
  Retourne: { agents[] } - pour le catalogue des cibles

✓ GET /api/live/campaigns
  Retourne: { campaigns[] } - pour le catalogue des cibles
```

### ❌ Problèmes Identifiés

#### 1. **Dépendance Backend Manquante**
**Symptôme:** L'UI est complète mais nécessite des endpoints backend non implémentés.

**Impact critère:** 
- Impossible de charger la configuration
- Impossible de sauvegarder les règles
- Les niveaux ne peuvent pas être créés
- Les règles ne peuvent pas être appliquées

**Fichiers affectés:**
- Backend: routes API inexistantes
- Base de données: tables `quality_levels`, `quality_rules`, `quality_rule_conditions`

#### 2. **Fonctions utilitaires manquantes**
**Symptôme:** Le code utilise des fonctions globales non définies dans live-quality-admin.js:
- `activate()` - change la vue active
- `setHead()` - définit le titre/sous-titre
- `api()` - effectue les appels API
- `canWriteInterface()` - vérifie les permissions
- `esc()` - échappe les caractères HTML (défini dans app.js ✓)

**Impact:** Code dépend entièrement d'app.js et supervision.js chargés avant

#### 3. **Intégration menu manquante**
**Symptôme:** Pas de lien vers "Signalisation Qualité Live" dans le menu de navigation.

**Impact:** Les utilisateurs ne peuvent pas accéder à l'interface

**Solution:**
```html
<!-- À ajouter dans index.html dans la section live-nav -->
<a href="#live-quality-admin" data-view="live-quality-admin" data-permission="live_quality_admin" data-write="1">
  <span>Signalisation Qualité Live</span>
</a>
```

#### 4. **Routeur de vues manquant**
**Symptôme:** Pas de fonction `liveQualityAdminView` enregistrée dans le routeur de vues.

**Impact:** Le clic sur le menu ne charge pas l'interface

**Solution:**
Dans app.js ou supervision.js, ajouter:
```javascript
'live-quality-admin': liveQualityAdminView,
```

---

## INTERFACE 2: INCIDENTS / ALERTES LIVE

### ✅ Implémentation Existante (live-views.js lignes 689-737)

#### Fonctionnalités Implémentées:
1. **Deux modes de visualisation**
   - Mode **Histoire** : tableau chronologique des incidents avec agent, règle, niveau, statut, durée
   - Mode **Statistiques** : résumé, incidents par agent, distribution par type/jour

2. **Filtrage par période**
   - Sélection date "de" et "à"
   - Intervalle maximal : 90 jours
   - Conservation de l'état en URL hash

3. **Pagination**
   - Taille de page configurable (10 items par défaut)
   - Navigation Précédent/Suivant
   - Affichage du numéro de page

4. **Affichage des données**
   - Timestamps formatés en français
   - Durée avec animation en temps réel
   - Codes de statut : NOUVEAU, VU, EN_INVESTIGATION, ACTION_EN_COURS, RETABLI, CLOTURE
   - Graphiques en barres pour la distribution

5. **Persistance**
   - État de la mode (history/stats) en URL hash
   - Période en URL hash
   - Numéro de page en URL hash

#### Endpoints API Attendus:
```
✓ GET /api/live/incidents?from=&to=&active=0&limit=10000
  Retourne: {
    incidents: [
      {
        triggered_at (timestamp unix),
        agent_name, agent (id),
        scope_type (AGENT, GROUP, CAMPAIGN),
        scope_label, scope_key,
        rule_name,
        category_label,
        level_label,
        color (hex),
        status (NOUVEAU, VU, etc),
        status_label,
        duration_seconds,
        reasons: [
          { usable, passed, ... }
        ]
      }
    ],
    period: { from, to },
    retention_days: 90
  }

✓ GET /api/live/incident-stats?from=&to=&active=0&limit=10000
  Retourne: {
    total,
    agent_incidents,
    collective_incidents,
    agents: [
      { agent, name, total, counts: { category_key: count }, last_incident_at }
    ],
    categories: [ { key, label, count } ],
    daily: [ { day, count } ]
  }
```

### ❌ Problèmes Identifiés

#### 1. **Endpoints API manquants**
**Symptôme:** Les endpoints `/api/live/incidents` et `/api/live/incident-stats` n'existent probablement pas en backend.

**Impact critique:**
- Impossible de charger l'historique
- Statistiques vides
- Interface non-fonctionnelle

**Fichiers affectés:**
- Backend: routes `/api/live/incidents` et `/api/live/incident-stats`
- Base de données: table `incidents` avec schéma approprié

#### 2. **Fonctions utilitaires manquantes ou incomplètes**
**Symptôme:** Références à des fonctions non vérifiées:

```javascript
// Défini ✓
- liveIncidentHashState()
- liveIncidentAgentLabel()
- liveIncidentDetails()
- liveIncidentBarChart()
- liveIncidentStatsTable()
- liveIncidentStatusLabel()
- liveIncidentTime()
- liveIncidentEventLabel()
- liveIncidentMetricFmt()

// Utilisé mais non vérifié
- liveReasonObserved(reason) - ligne 703
  Expected: Affiche la raison d'un incident
  
- liveQualityStatus(status, true) - ligne 728
  Used in: Affiche le niveau avec couleur
  Expected: Status object { label, color }

- liveDuration(seconds) - utilisé ligne 728
  Status: Défini dans live-views.js ligne 59 ✓
```

#### 3. **Pas de sauvegarde d'incidents**
**Symptôme:** Pas de formulaire pour créer/modifier les incidents manuellement.

**Impact:** Les utilisateurs ne peuvent que consulter les incidents auto-générés par les règles, pas les sauvegarder manuellement.

**Solution:** Ajouter une interface de création d'incidents.

#### 4. **Pas de suivi/actions sur les incidents**
**Symptôme:** Pas de fonctionnalité pour mettre à jour le statut des incidents.

**Impact:** Les incidents restent figés dans leur statut initial, aucun workflow possible.

**Solution:** Ajouter des endpoints pour changer le statut:
```
PUT /api/live/incident/{id}/status
  Body: { status, comment? }
```

#### 5. **Pas de détail d'incident**
**Symptôme:** Clic sur un incident ne montre pas le détail complet.

**Impact:** Impossible d'investiguer un incident en détail.

**Solution:** Ajouter une modal/vue détail avec:
- Chronologie complète des événements
- Raisons du déclenchement détaillées
- Commentaires et actions prises
- Historique des changements de statut

#### 6. **Pas de recherche**
**Symptôme:** Impossible de filtrer les incidents par agent, règle, etc.

**Impact:** Avec des centaines d'incidents, très difficile de trouver celui qui nous intéresse.

**Solution:** Ajouter des filtres persistants (stockés en sessionStorage):
- Par agent
- Par règle/catégorie
- Par statut
- Par période

#### 7. **Pas de gestion de masse**
**Symptôme:** Impossible de marquer plusieurs incidents comme "VU" ou de les clôturer en masse.

**Impact:** Tâche fastidieuse pour gérer les incidents.

**Solution:** Checkbox de sélection multiple + actions en masse.

#### 8. **Pas d'export**
**Symptôme:** Impossible d'exporter les incidents en CSV/Excel.

**Impact:** Impossible de faire des rapports externes.

**Solution:** Bouton d'export CSV/JSON.

---

## 📊 Tableau Récapitulatif des Problèmes

| Composant | Problème | Sévérité | État |
|-----------|---------|----------|------|
| Signalisation QL Live | Backend API non implémenté | CRITIQUE | ❌ |
| Signalisation QL Live | Menu de navigation manquant | HAUTE | ❌ |
| Signalisation QL Live | Routeur de vues manquant | HAUTE | ❌ |
| Incidents / Alertes | Backend API non implémenté | CRITIQUE | ❌ |
| Incidents / Alertes | Pas de sauvegarde d'incidents | HAUTE | ❌ |
| Incidents / Alertes | Pas de workflow de statut | HAUTE | ❌ |
| Incidents / Alertes | Pas de modal de détail | MOYENNE | ❌ |
| Incidents / Alertes | Pas de recherche/filtres | MOYENNE | ❌ |
| Incidents / Alertes | Pas de gestion de masse | MOYENNE | ❌ |
| Incidents / Alertes | Pas d'export | BASSE | ❌ |

---

## 🛠️ Plan d'Implémentation

### Phase 1: Rendre les interfaces fonctionnelles (URGENT)
1. ✅ Intégrer le lien "Signalisation Qualité Live" au menu
2. ✅ Enregistrer la fonction dans le routeur de vues
3. ❌ **Implémenter les endpoints backend** (côté serveur - BLOQUANT)
4. ❌ **Créer la structure de BD** (côté serveur - BLOQUANT)

### Phase 2: Améliorer Incidents / Alertes (IMPORTANT)
1. ✅ Ajouter interface de sauvegarde manuelle d'incidents
2. ✅ Ajouter gestion de statut (VU, EN_INVESTIGATION, etc)
3. ✅ Ajouter modal de détail d'incident
4. ✅ Ajouter filtres persistants avec recherche
5. ✅ Ajouter sélection multiple et actions en masse
6. ✅ Ajouter export CSV/JSON

### Phase 3: Optimisations (BONUS)
1. Notifications en temps réel des nouveaux incidents (WebSocket)
2. Graphiques interactifs
3. Intégration avec le système de tickets
4. Alertes email/SMS

---

## 📝 Checklist de Validation

### Signalisation Qualité Live
- [ ] Endpoint `/api/live/quality/config` fonctionne
- [ ] Création d'un nouveau niveau persiste en BD
- [ ] Création d'une nouvelle règle persiste en BD
- [ ] Les niveaux s'affichent correctement avec leurs couleurs
- [ ] Les règles s'appliquent aux agents en temps réel
- [ ] Le Centre Qualité Live affiche les couleurs des incidents

### Incidents / Alertes Live
- [ ] Endpoint `/api/live/incidents` retourne des incidents
- [ ] Endpoint `/api/live/incident-stats` retourne les statistiques
- [ ] Mode Histoire affiche le tableau
- [ ] Mode Statistiques affiche les résumés
- [ ] Filtrage par période fonctionne
- [ ] Pagination fonctionne
- [ ] Incidents sauvegardés manuellement apparaissent
- [ ] Statuts changeables

---

## ⚠️ Points Critiques à Adresser

### 1. Absence complète de persistance backend
- **Problème:** Les deux interfaces sont des façades sans backend
- **Impact:** Zéro fonctionnalité réelle
- **Délai estimé:** 2-3 jours de développement backend

### 2. Pas de base de données pour les incidents
- **Problème:** Aucun stockage des incidents créés
- **Impact:** Les incidents disparaissent au rechargement
- **Solution:** Table `incidents` avec indexes sur `agent_id`, `rule_id`, `created_at`

### 3. Pas de mécanisme de génération d'incidents
- **Problème:** Seul le backend peut créer des incidents
- **Impact:** Les règles Qualité Live ne déclenchent rien
- **Solution:** Service/cron qui évalue les règles toutes les 5 secondes

---

## 🚀 Recommandations

1. **IMMÉDIAT:** Implémenter les endpoints API côté backend
2. **IMMÉDIAT:** Créer les tables de base de données nécessaires
3. **COURT TERME:** Ajouter la sauvegarde manuelle d'incidents
4. **COURT TERME:** Ajouter le workflow de statut
5. **MOYEN TERME:** Ajouter les filtres et la recherche
6. **LONG TERME:** Ajouter les notifications en temps réel

---

**Diagnostic réalisé:** 2026-10-01  
**Version:** RC29.4  
**Auteur:** Claude Code  

