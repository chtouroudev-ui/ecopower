# Guide d'Implémentation : Corrections RC29.4

## 1️⃣ FIX INDEX.HTML - Ajouter le lien "Signalisation Qualité Live"

### Localisation: `index.html` ligne 33

**À chercher:**
```html
<a href="#live-incidents" data-view="live-incidents" data-permission="collection"><span>Incidents / Alertes</span></a>
```

**À remplacer par:**
```html
<a href="#live-incidents" data-view="live-incidents" data-permission="collection"><span>Incidents / Alertes</span></a>
<a href="#live-quality-admin" data-view="live-quality-admin" data-permission="live_quality_admin" data-write="1"><span>Signalisation Qualité Live</span></a>
```

---

## 2️⃣ FIX LIVE-VIEWS.JS - Enregistrer "live-quality-admin" dans le routeur

### Localisation: `static/live-views.js` ~ligne 800-850 (chercher le dictionnaire `views`)

**À ajouter dans l'objet views:**
```javascript
'live-quality-admin': liveQualityAdminView,
```

**Context (chercher ceci):**
```javascript
const views = {
  'live-supervision': liveSupervisionView,
  'live-campaigns': liveCampaignsView,
  'live-incidents': liveIncidentsView,
  'live-search': liveSearchView,
  // À ajouter:
  'live-quality-admin': liveQualityAdminView,
  // ... autres vues
};
```

---

## 3️⃣ NEW FILE: static/live-incidents-improved.js

**Créer ce fichier avec les améliorations:**

```javascript
// Centre Qualité Live - Gestion Améliorée des Incidents RC29.4

// État global des incidents
let liveIncidentsImprovedState = {
  mode: sessionStorage.getItem('nelyio_incidents_mode') || 'history',
  from: '',
  to: '',
  page: 0,
  pageSize: 10,
  filter: {
    agent: sessionStorage.getItem('nelyio_incidents_filter_agent') || '',
    category: sessionStorage.getItem('nelyio_incidents_filter_category') || '',
    status: sessionStorage.getItem('nelyio_incidents_filter_status') || '',
    search: ''
  },
  selected: [],
  showNewIncidentForm: false
};

// Sauvegarde les paramètres de filtre
function saveIncidentFilters() {
  sessionStorage.setItem('nelyio_incidents_filter_agent', liveIncidentsImprovedState.filter.agent);
  sessionStorage.setItem('nelyio_incidents_filter_category', liveIncidentsImprovedState.filter.category);
  sessionStorage.setItem('nelyio_incidents_filter_status', liveIncidentsImprovedState.filter.status);
  sessionStorage.setItem('nelyio_incidents_mode', liveIncidentsImprovedState.mode);
}

// Formatage des statuts
function incidentStatusBadge(status) {
  const colors = {
    'NOUVEAU': '#3b82f6',
    'VU': '#8b5cf6',
    'EN_INVESTIGATION': '#f97316',
    'ACTION_EN_COURS': '#ef4444',
    'RETABLI': '#22c55e',
    'CLOTURE': '#6b7280'
  };
  const labels = {
    'NOUVEAU': '🆕 Nouveau',
    'VU': '👁️ Vu',
    'EN_INVESTIGATION': '🔍 Investigation',
    'ACTION_EN_COURS': '⚙️ Action',
    'RETABLI': '✓ Rétabli',
    'CLOTURE': '✔️ Clôturé'
  };
  const color = colors[status] || '#9ca3af';
  const label = labels[status] || status;
  return `<span class="incident-status-badge" style="background:${color}14;color:${color};border:1px solid ${color};padding:0.25rem 0.5rem;border-radius:4px;font-weight:600;white-space:nowrap;font-size:0.85em">${label}</span>`;
}

// Formulaire de création d'incident
function renderIncidentForm() {
  return `
    <details class="card panel" id="lq-new-incident-form">
      <summary><strong>+ Ajouter un incident manuellement</strong></summary>
      <form class="lq-incident-form">
        <div class="lq-grid">
          <label>
            Agent / Périmètre
            <input name="scope_key" type="text" placeholder="ex. Agent 571 ou GROUP:MED" required>
          </label>
          <label>
            Type de cible
            <select name="scope_type" required>
              <option value="">Sélectionner...</option>
              <option value="AGENT">Agent</option>
              <option value="GROUP">Groupe</option>
              <option value="CAMPAIGN">Campagne</option>
              <option value="SERVICE">Service</option>
            </select>
          </label>
        </div>
        <div class="lq-grid">
          <label>
            Règle / Catégorie
            <input name="rule_name" type="text" placeholder="ex. Post-appel trop long" required>
          </label>
          <label>
            Niveau
            <select name="level_key" required>
              <option value="">Sélectionner...</option>
              <option value="WARNING">⚠️ Attention</option>
              <option value="ALERT">🔔 Alerte</option>
              <option value="CRITICAL">🚨 Critique</option>
            </select>
          </label>
        </div>
        <label>
          Détail / Raison
          <textarea name="detail" placeholder="Raison du déclenchement de cet incident..." rows="3"></textarea>
        </label>
        <div class="lq-actions">
          <button type="submit" class="button">Créer l'incident</button>
          <span class="form-result" style="margin-left:1rem;"></span>
        </div>
      </form>
    </details>
  `;
}

// Affichage compact de l'historique avec filtres
function renderIncidentsHistoryWithFilters(data, filters) {
  const incidents = data.incidents || [];
  const categories = [...new Set(incidents.map(i => i.category_label))].filter(Boolean);
  const statuses = ['NOUVEAU', 'VU', 'EN_INVESTIGATION', 'ACTION_EN_COURS', 'RETABLI', 'CLOTURE'];
  
  // Appliquer les filtres
  let filtered = incidents;
  if (filters.agent) {
    filtered = filtered.filter(i => {
      const agent = String(i.agent || i.agent_name || '').toLowerCase();
      return agent.includes(filters.agent.toLowerCase());
    });
  }
  if (filters.category) {
    filtered = filtered.filter(i => i.category_label === filters.category);
  }
  if (filters.status) {
    filtered = filtered.filter(i => i.status === filters.status);
  }
  if (filters.search) {
    const q = filters.search.toLowerCase();
    filtered = filtered.filter(i => {
      return String(i.rule_name || '').toLowerCase().includes(q) ||
             String(i.agent_name || '').toLowerCase().includes(q);
    });
  }
  
  // Pagination
  const pageSize = 15;
  const pages = Math.max(1, Math.ceil(filtered.length / pageSize));
  const page = Math.min(liveIncidentsImprovedState.page, pages - 1);
  const visible = filtered.slice(page * pageSize, (page + 1) * pageSize);
  
  return `
    <div class="live-incidents-filters-bar">
      <input type="search" id="incident-search" placeholder="Rechercher..." value="${esc(filters.search)}" style="flex:1;min-width:150px;">
      <select id="incident-filter-agent" style="min-width:120px;">
        <option value="">Agent (Tous)</option>
        ${[...new Set(incidents.map(i => i.agent))].filter(Boolean).map(a => `<option value="${esc(a)}" ${filters.agent === a ? 'selected' : ''}>${esc(a)}</option>`).join('')}
      </select>
      <select id="incident-filter-category" style="min-width:140px;">
        <option value="">Catégorie (Toutes)</option>
        ${categories.map(c => `<option value="${esc(c)}" ${filters.category === c ? 'selected' : ''}>${esc(c)}</option>`).join('')}
      </select>
      <select id="incident-filter-status" style="min-width:130px;">
        <option value="">Statut (Tous)</option>
        ${statuses.map(s => `<option value="${s}" ${filters.status === s ? 'selected' : ''}>${esc({
          'NOUVEAU': '🆕 Nouveau',
          'VU': '👁️ Vu',
          'EN_INVESTIGATION': '🔍 Investigation',
          'ACTION_EN_COURS': '⚙️ Action',
          'RETABLI': '✓ Rétabli',
          'CLOTURE': '✔️ Clôturé'
        }[s] || s)}</option>`).join('')}
      </select>
      <button class="button ghost" id="incident-filter-reset">Réinitialiser</button>
    </div>
    
    <div class="table-wrap">
      <table class="live-incident-history-table-improved">
        <thead>
          <tr>
            <th style="width:30px;">
              <input type="checkbox" id="incident-select-all" ${liveIncidentsImprovedState.selected.length === visible.length && visible.length > 0 ? 'checked' : ''}>
            </th>
            <th>Date / heure</th>
            <th>Agent</th>
            <th>Incident</th>
            <th>Statut</th>
            <th>Durée</th>
            <th style="width:80px;">Actions</th>
          </tr>
        </thead>
        <tbody>
          ${visible.map((i, idx) => `
            <tr data-incident-id="${esc(i.id || idx)}" style="background:${['NOUVEAU', 'EN_INVESTIGATION'].includes(i.status) ? '#fef3c7' : 'white'}">
              <td style="text-align:center;">
                <input type="checkbox" class="incident-checkbox" value="${esc(i.id || idx)}" ${liveIncidentsImprovedState.selected.includes(i.id || idx) ? 'checked' : ''}>
              </td>
              <td style="white-space:nowrap;">${esc(liveIncidentTime(i.triggered_at || i.first_seen))}</td>
              <td><strong>${esc(i.agent_name || i.scope_label || '—')}</strong><small>${esc(i.agent || '')}</small></td>
              <td><strong>${esc(i.category_label || 'Incident')}</strong><small>${esc(i.rule_name || '')}</small></td>
              <td>${incidentStatusBadge(i.status)}</td>
              <td>${esc(liveDuration(i.duration_seconds || 0))}</td>
              <td>
                <button class="button ghost small" data-incident-action="detail" data-incident-id="${esc(i.id || idx)}">Détail</button>
              </td>
            </tr>
          `).join('')}
        </tbody>
      </table>
      ${visible.length === 0 ? `<div class="empty" style="padding:2rem;text-align:center;color:#9ca3af;">Aucun incident ne correspond aux critères.</div>` : ''}
    </div>
    
    ${filtered.length > pageSize ? `
      <div class="sup-pager">
        <button class="button ghost" id="incident-prev" ${page <= 0 ? 'disabled' : ''}>Précédent</button>
        <span>Page ${page + 1} / ${pages}</span>
        <button class="button ghost" id="incident-next" ${page + 1 >= pages ? 'disabled' : ''}>Suivant</button>
      </div>
    ` : ''}
  `;
}

// Export en CSV
function exportIncidentsCSV(incidents) {
  if (!incidents.length) {
    alert('Aucun incident à exporter.');
    return;
  }
  const headers = ['Date', 'Agent', 'Catégorie', 'Règle', 'Statut', 'Durée (s)', 'Détails'];
  const rows = incidents.map(i => [
    new Date(Number(i.triggered_at || 0) * 1000).toLocaleString('fr-FR'),
    i.agent_name || i.agent || '—',
    i.category_label || '—',
    i.rule_name || '—',
    i.status || '—',
    i.duration_seconds || 0,
    i.detail || ''
  ]);
  
  const csv = [
    headers.join(';'),
    ...rows.map(r => r.map(cell => `"${String(cell).replace(/"/g, '""')}"`).join(';'))
  ].join('\n');
  
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  link.setAttribute('href', URL.createObjectURL(blob));
  link.setAttribute('download', `incidents-${new Date().toISOString().split('T')[0]}.csv`);
  link.click();
}

// Changement de statut d'incident
async function updateIncidentStatus(incidentId, newStatus, comment) {
  try {
    await api('/api/live/incident/' + encodeURIComponent(incidentId) + '/status', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status: newStatus, comment: comment || '' })
    });
    return true;
  } catch (err) {
    alert('Erreur: ' + err.message);
    return false;
  }
}

// Export global
window.LiveIncidentsImproved = {
  renderIncidentForm,
  renderIncidentsHistoryWithFilters,
  exportIncidentsCSV,
  updateIncidentStatus,
  state: liveIncidentsImprovedState,
  saveFilters: saveIncidentFilters
};
```

---

## 4️⃣ AMÉLIORATION: CSS pour incidents

**À ajouter à live-views-improved.css ou créer live-incidents-improved.css:**

```css
/* Filtres et actions incidents */
.live-incidents-filters-bar {
  display: flex;
  gap: 0.75rem;
  margin-bottom: 1rem;
  flex-wrap: wrap;
  align-items: center;
}

.live-incidents-filters-bar input,
.live-incidents-filters-bar select {
  padding: 0.5rem 0.75rem;
  border: 1px solid #d1d5db;
  border-radius: 6px;
  font-size: 0.875rem;
  background: white;
}

.incident-status-badge {
  display: inline-block;
  font-size: 0.85em;
  padding: 0.25rem 0.5rem;
  border-radius: 4px;
  font-weight: 600;
  white-space: nowrap;
}

.live-incident-history-table-improved {
  width: 100%;
  border-collapse: collapse;
}

.live-incident-history-table-improved th,
.live-incident-history-table-improved td {
  padding: 0.75rem;
  text-align: left;
  border-bottom: 1px solid #f3f4f6;
}

.live-incident-history-table-improved th {
  background: #f3f4f6;
  font-weight: 600;
  color: #374151;
  white-space: nowrap;
}

.live-incident-history-table-improved tbody tr:hover {
  background-color: #fafafa;
}

.live-incident-history-table-improved small {
  display: block;
  color: #9ca3af;
  font-size: 0.75em;
  margin-top: 0.25rem;
}

.lq-incident-form {
  padding: 1rem;
  background: #f9fafb;
  border-radius: 6px;
}

.lq-incident-form .lq-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 1rem;
  margin-bottom: 1rem;
}

.lq-incident-form label {
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
}

.lq-incident-form input,
.lq-incident-form select,
.lq-incident-form textarea {
  padding: 0.5rem 0.75rem;
  border: 1px solid #d1d5db;
  border-radius: 6px;
  font-size: 0.875rem;
  font-family: inherit;
}

.lq-incident-form textarea {
  resize: vertical;
  font-family: 'Monaco', monospace;
}

.lq-actions {
  display: flex;
  align-items: center;
  gap: 1rem;
  margin-top: 1rem;
}

.form-result {
  font-size: 0.85em;
  color: #059669;
}

.empty {
  text-align: center;
  color: #9ca3af;
  padding: 2rem;
}

/* Responsive */
@media (max-width: 900px) {
  .live-incidents-filters-bar {
    flex-direction: column;
  }
  
  .live-incidents-filters-bar input,
  .live-incidents-filters-bar select {
    width: 100%;
  }
  
  .live-incident-history-table-improved {
    font-size: 0.8em;
  }
  
  .live-incident-history-table-improved th,
  .live-incident-history-table-improved td {
    padding: 0.5rem 0.25rem;
  }
}
```

---

## 5️⃣ INTÉGRATION: Charger le fichier dans index.html

**À ajouter après live-quality-admin.js:**

```html
<script src="/static/live-incidents-improved.js?v=RC29_4-FIX1"></script>
```

---

## 🚀 Validation Après Implémentation

### Checklist:
- [ ] Lien "Signalisation Qualité Live" visible dans le menu LIVE
- [ ] Clic sur ce lien ouvre la page (pas d'erreur 404)
- [ ] Page "Signalisation Qualité Live" s'affiche sans erreur JS
- [ ] Incidents page affiche les filtres
- [ ] Bouton "Ajouter un incident" fonctionne
- [ ] Export CSV fonctionne (télécharge un fichier)
- [ ] Filtrage par statut/agent fonctionne
- [ ] Pagination fonctionne

---

## 📦 Fichiers à modifier/créer

| Fichier | Action | Complexité |
|---------|--------|-----------|
| index.html | Ajouter 1 ligne au menu | ⭐ Trivial |
| static/live-views.js | Enregistrer 1 vue | ⭐ Trivial |
| static/live-incidents-improved.js | Créer nouveau | ⭐⭐ Faible |
| static/live-views-improved.css | Ajouter CSS | ⭐ Trivial |

---

**Prérequis:** Les endpoints backend doivent être implémentés pour que les données s'affichent.

